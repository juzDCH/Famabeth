import { useState, useEffect } from 'react';
import { Slot, usePathname, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { View, TouchableOpacity, Text, StyleSheet } from 'react-native';
import { auth } from '../../firebaseConfig'; // Asegúrate de tener la configuración de Firebase importada
import { onAuthStateChanged } from 'firebase/auth';

// Definir el tipo para las rutas posibles
type TabRoute = 
  | '/screens/Home/HomeScreen'
  | '/screens/Cart/Carrito'
  | '/screens/Cart/Categoria'
  | '/screens/Soporte/customer-support'
  | '/screens/Usuario/account';

// Definir el tipo para los íconos de Ionicons
type TabIcon = keyof typeof Ionicons.glyphMap;

const tabs = [
  { name: 'home', icon: 'home-outline' as TabIcon, label: 'Inicio', route: '/screens/Home/HomeScreen' as TabRoute },
  { name: 'carrito', icon: 'cart-outline' as TabIcon, label: 'Carrito', route: '/screens/Cart/Carrito' as TabRoute },
  { name: 'productos', icon: 'medkit-outline' as TabIcon, label: 'Productos', route: '/screens/Cart/Categoria' as TabRoute },
  { name: 'soporte', icon: 'help-circle-outline' as TabIcon, label: 'Soporte', route: '/screens/Soporte/customer-support' as TabRoute },
  { name: 'perfil', icon: 'person-outline' as TabIcon, label: 'Perfil', route: '/screens/Usuario/account' as TabRoute },
];

export default function GlobalLayout() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const pathname = usePathname();
  const router = useRouter();

  // Verificar si el usuario está autenticado al montar el componente
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (user) {
        setIsAuthenticated(true);
      } else {
        setIsAuthenticated(false);
      }
    });

    return () => unsubscribe();
  }, []);

  // Si no está autenticado, no mostrar los tabs
  if (!isAuthenticated) {
    return <Slot />; // Solo muestra el contenido principal, no la barra de navegación
  }

  return (
    <View style={{ flex: 1 }}>
      <Slot /> {/* Aquí se renderiza la pantalla actual */}

      {/* Footer tipo Tabs */}
      <View style={styles.tabBar}>
        {tabs.map((tab) => {
          const isActive = pathname === tab.route;
          return (
            <TouchableOpacity
              key={tab.name}
              style={styles.tabItem}
              onPress={() => router.push(tab.route)} 
            >
              <Ionicons
                name={tab.icon} 
                size={24}
                color={isActive ? '#4B0082' : 'gray'}
              />
              <Text style={{ color: isActive ? '#4B0082' : 'gray', fontSize: 12 }}>
                {tab.label}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  tabBar: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    backgroundColor: '#fff',
    paddingVertical: 8,
    borderTopWidth: 1,
    borderTopColor: '#ddd',
  },
  tabItem: {
    alignItems: 'center',
    flex: 1,
  },
});
