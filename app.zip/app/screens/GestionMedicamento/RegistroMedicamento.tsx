import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView, Alert } from 'react-native';
import { addDoc, collection } from 'firebase/firestore';
import { db } from '../../../firebaseConfig'; 
import { useRouter } from 'expo-router';

export default function CrearMedicamentoScreen() {
  const [nombre, setNombre] = useState('');
  const [descripcion, setDescripcion] = useState('');
  const [dosis, setDosis] = useState('');
  const [precio, setPrecio] = useState('');
  const [idCategoria, setIdCategoria] = useState('');
  const router = useRouter();

  const handleGuardar = async () => {
    try {
      if (!nombre || !descripcion || !dosis || !precio || !idCategoria) {
        Alert.alert('Error', 'Todos los campos son obligatorios');
        return;
      }

      await addDoc(collection(db, 'medicamento'), {
        nombre,
        descripcion,
        dosis,
        precio,
        idCategoria,
      });

      Alert.alert('Éxito', 'Medicamento registrado correctamente');
      //Clean
      setNombre('');
      setDescripcion('');
      setDosis('');
      setPrecio('');
      setIdCategoria('');

    } catch (error) {
      console.error('Error al guardar:', error);
      Alert.alert('Error', 'No se pudo registrar el medicamento');
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Registrar Medicamento</Text>

      <TextInput
        style={styles.input}
        placeholder="Nombre"
        value={nombre}
        onChangeText={setNombre}
      />

      <TextInput
        style={styles.input}
        placeholder="Descripción"
        value={descripcion}
        onChangeText={setDescripcion}
      />

      <TextInput
        style={styles.input}
        placeholder="Dosis"
        value={dosis}
        onChangeText={setDosis}
      />

      <TextInput
        style={styles.input}
        placeholder="Precio"
        value={precio}
        onChangeText={setPrecio}
        keyboardType="numeric"
      />

      <TextInput
        style={styles.input}
        placeholder="ID Categoría"
        value={idCategoria}
        onChangeText={setIdCategoria}
      />

      <TouchableOpacity style={styles.button} onPress={handleGuardar}>
        <Text style={styles.buttonText}>Guardar Medicamento</Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.button}
        onPress={() => router.push('/screens/GestionMedicamento/ListaMedicamentos')}
      >
        <Text style={styles.buttonText}>Lista Medicamentos</Text>
      </TouchableOpacity>

    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 20,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    padding: 10,
    marginBottom: 10,
  },
  button: {
    backgroundColor: '#4B0082',
    padding: 14,
    borderRadius: 8,
    alignItems: 'center',
    marginVertical: 10,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
  },
});
