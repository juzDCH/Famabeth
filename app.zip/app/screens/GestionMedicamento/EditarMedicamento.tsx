import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView, Modal, ActivityIndicator } from 'react-native';
import { useRoute, useNavigation } from '@react-navigation/native';
import { doc, updateDoc } from 'firebase/firestore';
import { db } from '../../../firebaseConfig';

interface Medicamento {
  id: string;
  nombre: string;
  descripcion: string;
  dosis: string;
  precio: number;
  id_categoria: string;
}

export default function EditarMedicamentoScreen() {
  const route = useRoute<any>();
  const navigation = useNavigation<any>();
  const { medicamento } = route.params || {};

  const [nombre, setNombre] = useState('');
  const [descripcion, setDescripcion] = useState('');
  const [dosis, setDosis] = useState('');
  const [precio, setPrecio] = useState('');
  const [idCategoria, setIdCategoria] = useState('');

  const [modalVisible, setModalVisible] = useState(false);

  useEffect(() => {
    if (medicamento) {
      setNombre(medicamento.nombre || '');
      setDescripcion(medicamento.descripcion || '');
      setDosis(medicamento.dosis || '');
      setPrecio(medicamento.precio ? medicamento.precio.toString() : '');
      setIdCategoria(medicamento.id_categoria || '');
    }
  }, [medicamento]);

  const handleActualizar = async () => {
    if (!nombre || !descripcion || !dosis || !precio || !idCategoria) {
      alert('Todos los campos son obligatorios');
      return;
    }

    try {
      const medicamentoRef = doc(db, 'medicamento', medicamento.id);
      await updateDoc(medicamentoRef, {
        nombre,
        descripcion,
        dosis,
        precio: Number(precio),
        id_categoria: idCategoria,
      });

      setModalVisible(true);
      setTimeout(() => {
        setModalVisible(false);
        navigation.goBack();
      }, 2000);
    } catch (error) {
      console.error('Error actualizando:', error);
      alert('Error al actualizar');
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Editar Medicamento</Text>

      <Text style={styles.label}>Nombre</Text>
      <TextInput value={nombre} onChangeText={setNombre} placeholder="Nombre" style={styles.input} />

      <Text style={styles.label}>Descripción</Text>
      <TextInput value={descripcion} onChangeText={setDescripcion} placeholder="Descripción" style={styles.input} />

      <Text style={styles.label}>Dosis</Text>
      <TextInput value={dosis} onChangeText={setDosis} placeholder="Dosis" style={styles.input} />

      <Text style={styles.label}>Precio</Text>
      <TextInput
        value={precio}
        onChangeText={(text) => setPrecio(text)}
        placeholder="Precio"
        keyboardType="numeric"
        style={styles.input}
      />
      
      <Text style={styles.label}>ID Categoría</Text>
      <TextInput value={idCategoria} onChangeText={setIdCategoria} placeholder="ID Categoría" style={styles.input} />

      <TouchableOpacity style={styles.button} onPress={handleActualizar}>
        <Text style={styles.buttonText}>Actualizar Medicamento</Text>
      </TouchableOpacity>

      <Modal visible={modalVisible} transparent animationType="fade">
        <View style={styles.modalBackground}>
          <View style={styles.modalContent}>
            <ActivityIndicator size="large" color="#4B0082" />
            <Text style={styles.modalText}>Actualizando...</Text>
          </View>
        </View>
      </Modal>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: '#fff',
    flexGrow: 1,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    padding: 10,
    marginBottom: 15,
  },
  button: {
    backgroundColor: '#4B0082',
    padding: 12,
    borderRadius: 8,
    marginTop: 10,
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  modalBackground: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  modalContent: {
    backgroundColor: '#fff',
    padding: 30,
    borderRadius: 10,
    alignItems: 'center',
  },
  modalText: {
    marginTop: 10,
    fontSize: 16,
    color: '#4B0082',
    fontWeight: 'bold',
  },
  label: {
    fontSize: 14,
    fontWeight: 'bold',
    marginBottom: 4,
    marginTop: 10,
  }
  
});
