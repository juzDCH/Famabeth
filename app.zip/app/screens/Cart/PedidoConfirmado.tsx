import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { useRouter } from 'expo-router';


export default function PedidoConfirmado() {
  const router = useRouter();

  const handleRegresar = () => {
    // Lógica para regresar a la pantalla de inicio o de carrito
    router.push('/');  // Puedes cambiar la ruta a donde desees redirigir
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>¡Pedido Confirmado!</Text>
      <Text style={styles.subtitle}>Tu pedido ha sido recibido con éxito.</Text>
      <Text style={styles.text}>Te contactaremos pronto para confirmar los detalles de tu entrega.</Text>

      <TouchableOpacity style={styles.button} onPress={handleRegresar}>
        <Text style={styles.buttonText}>Regresar a la página principal</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#4B0082',
    marginBottom: 20,
  },
  subtitle: {
    fontSize: 18,
    fontWeight: '500',
    marginBottom: 10,
  },
  text: {
    fontSize: 16,
    color: '#555',
    textAlign: 'center',
    marginBottom: 20,
  },
  button: {
    backgroundColor: '#4B0082',
    padding: 15,
    borderRadius: 8,
    width: '100%',
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
  },
});
