import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, FlatList, ActivityIndicator } from 'react-native';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '../../../firebaseConfig';

export default function PedidosLista() {
  const [pedidos, setPedidos] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const cargarPedidos = async () => {
      try {
        const snap = await getDocs(collection(db, 'comprobantes'));
        const data = snap.docs.map(doc => ({
          id: doc.id,
          ...doc.data(),
        }));
        setPedidos(data);
      } catch (error) {
        console.error('Error al cargar pedidos:', error);
      } finally {
        setLoading(false);
      }
    };

    cargarPedidos();
  }, []);

  const renderItem = ({ item }: any) => (
    <View style={styles.card}>
      <Text style={styles.titulo}>Pedido #{item.id.slice(0, 6)}</Text>
      <Text>Total: {item.total?.toFixed(2)} Bs</Text>
      <Text>Estado: <Text style={styles.estado}>{item.estado || 'En revisión'}</Text></Text>
      <Text>Fecha: {item.creado_en?.toDate?.().toLocaleString() || 'Desconocida'}</Text>
    </View>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Mis Pedidos</Text>
      {loading ? (
        <ActivityIndicator size="large" color="#6a1b9a" />
      ) : (
        <FlatList
          data={pedidos}
          keyExtractor={(item) => item.id}
          renderItem={renderItem}
          contentContainerStyle={{ paddingBottom: 20 }}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 20,
  },
  header: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#4a148c',
    marginBottom: 20,
    textAlign: 'center',
  },
  card: {
    backgroundColor: '#f4f4f4',
    borderRadius: 10,
    padding: 15,
    marginBottom: 15,
    elevation: 2,
  },
  titulo: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 4,
  },
  estado: {
    fontWeight: 'bold',
    color: '#6a1b9a',
  },
});
