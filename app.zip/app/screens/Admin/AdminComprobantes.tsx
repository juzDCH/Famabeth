import React, { useEffect, useState } from 'react';
import { View, Text, Image, FlatList, StyleSheet, ActivityIndicator } from 'react-native';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '../../../firebaseConfig';
import moment from 'moment';

export default function AdminComprobantes() {
  const [comprobantes, setComprobantes] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchComprobantes = async () => {
      try {
        const snapshot = await getDocs(collection(db, 'comprobantes'));
        const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        setComprobantes(data);
      } catch (error) {
        console.error('Error al obtener comprobantes:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchComprobantes();
  }, []);

  const renderItem = ({ item }: any) => (
    <View style={styles.card}>
      <Image source={{ uri: item.imagen_url }} style={styles.imagen} />
      <Text style={styles.total}>Total: Bs {item.total.toFixed(2)}</Text>
      <Text style={styles.fecha}>
        Fecha: {item.creado_en?.toDate ? moment(item.creado_en.toDate()).format('DD/MM/YYYY HH:mm') : 'Desconocida'}
      </Text>
    </View>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Comprobantes Recibidos</Text>
      {loading ? (
        <ActivityIndicator size="large" color="#6a1b9a" style={{ marginTop: 30 }} />
      ) : (
        <FlatList
          data={comprobantes}
          keyExtractor={(item) => item.id}
          renderItem={renderItem}
          contentContainerStyle={{ paddingBottom: 20 }}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingTop: 50,
    paddingHorizontal: 16,
    backgroundColor: '#fff',
    flex: 1,
  },
  header: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#4a148c',
    textAlign: 'center',
    marginBottom: 20,
  },
  card: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 10,
    padding: 16,
    marginBottom: 16,
    backgroundColor: '#f9f9f9',
  },
  imagen: {
    width: '100%',
    height: 200,
    borderRadius: 8,
    marginBottom: 12,
    resizeMode: 'cover',
  },
  total: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  fecha: {
    fontSize: 14,
    color: '#666',
    marginTop: 4,
  },
});
